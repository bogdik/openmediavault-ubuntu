Plugins must place their route manifest here.
