Run the PHP, Python and Javascript unit tests in the Vagrant development
environment. To prepare the development environment, simply execute the
following command in every subdirectory to install all necessary packages.

```shell
$ apt-get install make
$ cd javascript|php|python
$ make install
$ make test
```
