Insert your executable shell scripts here, which are to be executed by the
`smartctl-hdparm` systemd service at startup or after waking up from sleep
mode.
These scripts can be used to execute `smartctl` command calls that result
in enabling or disabling various SMART or non-SMART settings on disks.
