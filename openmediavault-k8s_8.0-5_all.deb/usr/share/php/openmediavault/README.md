$ sudo apt-get install composer
$ composer install --prefer-dist
