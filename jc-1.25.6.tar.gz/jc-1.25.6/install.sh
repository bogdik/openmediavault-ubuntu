#!/bin/bash
pip3 install --upgrade --user -e .