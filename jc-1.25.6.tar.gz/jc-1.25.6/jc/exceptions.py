"""jc - JSON Convert exceptions"""


class ParseError(Exception):
    pass


class LibraryNotInstalled(Exception):
    pass
